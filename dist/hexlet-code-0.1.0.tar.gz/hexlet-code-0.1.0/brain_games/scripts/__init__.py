"""Run scripts."""
