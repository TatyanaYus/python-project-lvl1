"""Run brain games."""
